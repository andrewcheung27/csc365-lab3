/* Author: Andrew Cheung */
/* Email: acheun29@calpoly.edu */


DROP TABLE Items;
DROP TABLE Receipts;
DROP TABLE Customers;
DROP TABLE Goods;
