# CSC 365 Lab 3 - Potpourri

## Author: Andrew Cheung
## Email: acheun29@calpoly.edu
