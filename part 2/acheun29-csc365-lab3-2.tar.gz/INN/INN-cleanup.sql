/* Author: Andrew Cheung */
/* Email: acheun29@calpoly.edu */


DROP TABLE Reservations;
DROP TABLE Rooms;
