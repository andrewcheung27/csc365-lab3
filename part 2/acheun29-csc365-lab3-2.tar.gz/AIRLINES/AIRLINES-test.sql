/* Author: Andrew Cheung */
/* Email: acheun29@calpoly.edu */


SELECT * FROM Flights;
SELECT COUNT(*) FROM Flights;


SELECT * FROM Airlines;
SELECT COUNT(*) FROM Airlines;


SELECT * FROM Airports100;
SELECT COUNT(*) FROM Airports100;


