/* Author: Andrew Cheung */
/* Email: acheun29@calpoly.edu */


DROP TABLE Flights;
DROP TABLE Airlines;
DROP TABLE Airports100;
