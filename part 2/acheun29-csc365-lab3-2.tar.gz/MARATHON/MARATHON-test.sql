/* Author: Andrew Cheung */
/* Email: acheun29@calpoly.edu */


SELECT * FROM Marathon;
SELECT COUNT(*) FROM Marathon;


