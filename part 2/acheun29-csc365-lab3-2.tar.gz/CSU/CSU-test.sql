/* Author: Andrew Cheung */
/* Email: acheun29@calpoly.edu */


SELECT * FROM CsuFees;
SELECT COUNT(*) FROM CsuFees;


SELECT * FROM Faculty;
SELECT COUNT(*) FROM Faculty;


SELECT * FROM Enrollments;
SELECT COUNT(*) FROM Enrollments;


SELECT * FROM DisciplineEnrollments;
SELECT COUNT(*) FROM DisciplineEnrollments;


SELECT * FROM Degrees;
SELECT COUNT(*) FROM Degrees;


SELECT * FROM Disciplines;
SELECT COUNT(*) FROM Disciplines;


SELECT * FROM Campuses;
SELECT COUNT(*) FROM Campuses;


