/* Author: Andrew Cheung */
/* Email: acheun29@calpoly.edu */


DROP TABLE Vocals;
DROP TABLE Performance;
DROP TABLE Instruments;
DROP TABLE Tracklists;
DROP TABLE Albums;
DROP TABLE Songs;
DROP TABLE Band;
