/* Author: Andrew Cheung */
/* Email: acheun29@calpoly.edu */


INSERT INTO Tracklists
VALUES(1, 1, 1);

INSERT INTO Tracklists
VALUES(1, 2, 2);

INSERT INTO Tracklists
VALUES(1, 3, 3);

INSERT INTO Tracklists
VALUES(1, 4, 4);

INSERT INTO Tracklists
VALUES(1, 5, 5);

INSERT INTO Tracklists
VALUES(1, 6, 6);

INSERT INTO Tracklists
VALUES(1, 7, 7);

INSERT INTO Tracklists
VALUES(1, 8, 8);

INSERT INTO Tracklists
VALUES(1, 9, 9);

INSERT INTO Tracklists
VALUES(1, 10, 10);

INSERT INTO Tracklists
VALUES(1, 11, 11);

INSERT INTO Tracklists
VALUES(1, 12, 12);

INSERT INTO Tracklists
VALUES(1, 13, 13);

INSERT INTO Tracklists
VALUES(2, 1, 14);

INSERT INTO Tracklists
VALUES(2, 2, 15);

INSERT INTO Tracklists
VALUES(2, 3, 16);

INSERT INTO Tracklists
VALUES(2, 4, 17);

INSERT INTO Tracklists
VALUES(2, 5, 18);

INSERT INTO Tracklists
VALUES(2, 6, 19);

INSERT INTO Tracklists
VALUES(2, 7, 20);

INSERT INTO Tracklists
VALUES(2, 8, 21);

INSERT INTO Tracklists
VALUES(2, 9, 22);

INSERT INTO Tracklists
VALUES(2, 10, 23);

INSERT INTO Tracklists
VALUES(2, 11, 24);

INSERT INTO Tracklists
VALUES(2, 12, 25);

INSERT INTO Tracklists
VALUES(3, 1, 14);

INSERT INTO Tracklists
VALUES(3, 2, 26);

INSERT INTO Tracklists
VALUES(3, 3, 3);

INSERT INTO Tracklists
VALUES(3, 4, 15);

INSERT INTO Tracklists
VALUES(3, 5, 11);

INSERT INTO Tracklists
VALUES(3, 6, 19);

INSERT INTO Tracklists
VALUES(3, 7, 18);

INSERT INTO Tracklists
VALUES(3, 8, 16);

INSERT INTO Tracklists
VALUES(3, 9, 12);

INSERT INTO Tracklists
VALUES(3, 10, 17);

INSERT INTO Tracklists
VALUES(3, 11, 22);

INSERT INTO Tracklists
VALUES(3, 12, 20);

INSERT INTO Tracklists
VALUES(3, 13, 2);

INSERT INTO Tracklists
VALUES(3, 14, 5);

INSERT INTO Tracklists
VALUES(3, 15, 8);

INSERT INTO Tracklists
VALUES(3, 16, 7);

INSERT INTO Tracklists
VALUES(3, 17, 25);

INSERT INTO Tracklists
VALUES(3, 18, 13);

INSERT INTO Tracklists
VALUES(3, 19, 24);

INSERT INTO Tracklists
VALUES(4, 1, 33);

INSERT INTO Tracklists
VALUES(4, 2, 41);

INSERT INTO Tracklists
VALUES(4, 3, 34);

INSERT INTO Tracklists
VALUES(4, 4, 35);

INSERT INTO Tracklists
VALUES(4, 5, 31);

INSERT INTO Tracklists
VALUES(4, 6, 36);

INSERT INTO Tracklists
VALUES(4, 7, 30);

INSERT INTO Tracklists
VALUES(4, 8, 37);

INSERT INTO Tracklists
VALUES(4, 9, 38);

INSERT INTO Tracklists
VALUES(4, 10, 39);

INSERT INTO Tracklists
VALUES(4, 11, 40);

