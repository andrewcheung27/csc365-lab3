/* Author: Andrew Cheung */
/* Email: acheun29@calpoly.edu */


SELECT * FROM List;
SELECT COUNT(*) FROM List;


SELECT * FROM Teachers;
SELECT COUNT(*) FROM Teachers;


