/* Author: Andrew Cheung */
/* Email: acheun29@calpoly.edu */


source CARS/CARS-setup.sql;
source CARS/CARS-insert.sql;
source CARS/CARS-modify.sql;
source CARS/CARS-cleanup.sql;
