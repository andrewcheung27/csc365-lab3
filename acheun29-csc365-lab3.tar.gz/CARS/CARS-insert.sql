/* Author: Andrew Cheung */
/* Email: acheun29@calpoly.edu */


source CARS/CARS-build-continents.sql
source CARS/CARS-build-countries.sql
source CARS/CARS-build-car-makers.sql
source CARS/CARS-build-model-list.sql
source CARS/CARS-build-car-names.sql
source CARS/CARS-build-cars-data.sql
