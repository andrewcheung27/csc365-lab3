/* Author: Andrew Cheung */
/* Email: acheun29@calpoly.edu */


DROP TABLE CarsData;
DROP TABLE CarNames;
DROP TABLE ModelList;
DROP TABLE CarMakers;
DROP TABLE Countries;
DROP TABLE Continents;
