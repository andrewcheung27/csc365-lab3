/* Author: Andrew Cheung */
/* Email: acheun29@calpoly.edu */


DROP TABLE Wine;
DROP TABLE Appellations;
DROP TABLE Grapes;
