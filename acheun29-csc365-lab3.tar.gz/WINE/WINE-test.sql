/* Author: Andrew Cheung */
/* Email: acheun29@calpoly.edu */


source WINE/WINE-setup.sql;
source WINE/WINE-insert.sql;
source WINE/WINE-modify.sql;
source WINE/WINE-cleanup.sql;
