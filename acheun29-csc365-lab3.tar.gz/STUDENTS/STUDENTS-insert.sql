/* Author: Andrew Cheung */
/* Email: acheun29@calpoly.edu */


source STUDENTS/STUDENTS-build-teachers.sql
source STUDENTS/STUDENTS-build-list.sql
