/* Author: Andrew Cheung */
/* Email: acheun29@calpoly.edu */


source STUDENTS/STUDENTS-setup.sql;
source STUDENTS/STUDENTS-insert.sql;
source STUDENTS/STUDENTS-modify.sql;
source STUDENTS/STUDENTS-cleanup.sql;
